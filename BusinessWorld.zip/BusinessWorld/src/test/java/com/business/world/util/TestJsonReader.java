package com.business.world.util;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.business.world.entity.AddressEntity;
import com.business.world.entity.EmployeeEntity;

public class TestJsonReader {

    @Test
    public void testJsonToEmployee () {
        List<EmployeeEntity> empList = new ArrayList<>();
        AddressEntity add = new AddressEntity();
        add.setCityName("Trivandrum");
        add.setHouseNumber(2156532);
        add.setStreetName("12 Hudson street");
        add.setStreetType("14A");
        add.setTelephoneNumber(34686532215L);
        add.setZipCode(695583);
        add.setAddressType("yz");
        


        EmployeeEntity e = new EmployeeEntity();

        e.setFirstName("varnika");
        e.setLastName("priydarshini");
        e.setSalary(123456);
        e.setAddress(add);
        empList.add(e);

		/*
		 * AddressEntity add2 = new AddressEntity(); add2.setCity("Ahmedabad");
		 * add2.setState("Gujrat"); add2.setStreetNum("12 Jhulelal street");
		 * add2.setZip("795543"); add2.setAddressline1("12 Cariappa");
		 * 
		 * 
		 * EmployeeEntity e2 = new EmployeeEntity();
		 * 
		 * e2.setFirstname("Vicky"); e2.setLastname("Malhotra"); e2.setSalary(34567);
		 * e2.setAddress(add2);
		 * 
		 * empList.add(e2);
		 */
        System.out.println(JsonReader.employeeToJson(empList));
        //System.out.println(JsonReader.employeeToJson(e2));
       // System.out.print(str);
    }
}
