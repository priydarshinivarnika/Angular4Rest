package com.business.world.service;

import java.util.List;
import com.business.world.entity.EmployeeEntity;

public interface IEmployeeService {

	public Integer createEmployee(String id, EmployeeEntity emp) throws Exception;

	public List<EmployeeEntity> getAllEmployees();

	public List<EmployeeEntity> getEmployeeById(String id);

	public EmployeeEntity updateEmployee(String id, EmployeeEntity emp) throws Exception;

	public void deleteEmployee(String id) throws Exception;
}
