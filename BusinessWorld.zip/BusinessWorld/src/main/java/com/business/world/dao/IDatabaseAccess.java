package com.business.world.dao;

import java.util.List;

import javax.transaction.SystemException;

import com.business.world.entity.EmployeeEntity;

public interface IDatabaseAccess {

	public Integer createEmployee(String id, EmployeeEntity emp) throws Exception;
	public List<EmployeeEntity> getAllEmployees();
	public List<EmployeeEntity> getEmployeeById(String id);

	public EmployeeEntity updateEmployee(String id, EmployeeEntity emp) throws Exception;

	public void deleteEmployee(String id) throws Exception;
	}
