package com.business.world.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ADDRESS")
public class AddressEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	private int addressId;
	private String cityName;
	private long telephoneNumber;
	private int zipCode;
	private int houseNumber;
	private String streetName;
	private String addressType;
	private String streetType;

	@Id
	@GeneratedValue
	@Column(name = "ADDRESS_ID")
	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	@Column(name = "CITY_NAME")
	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	@Column(name = "TELEPHONE_NUMBER")
	public long getTelephoneNumber() {
		return telephoneNumber;
	}

	public void setTelephoneNumber(long telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	@Column(name = "ZIP_CODE")
	public int getZipCode() {
		return zipCode;
	}

	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}

	@Column(name = "HOUSE_NUMBER")
	public int getHouseNumber() {
		return houseNumber;
	}

	public void setHouseNumber(int houseNumber) {
		this.houseNumber = houseNumber;
	}

	@Column(name = "STREET_NAME")
	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	@Column(name = "ADDRESS_TYPE")
	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	@Column(name = "STREET_TYPE")
	public String getStreetType() {
		return streetType;
	}

	public void setStreetType(String streetType) {
		this.streetType = streetType;
	}

	@Override
	public String toString() {
		return "Address {cityName=" + cityName + ", telephoneNumber=" + telephoneNumber + ", zipCode=" + zipCode
				+ ", houseNumber=" + houseNumber + ", streetName=" + streetName + ", addressType=" + addressType
				+ ", streetType=" + streetType + "}";
	}

}
