import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { EmployeeInfoComponent } from './employee-info/employee-info.component';
import { EmployeesComponent } from './employees/employees.component';
import { EmployeeService } from './employee.service';

import { AppRoutingModule } from './app-routing/app-routing.module';
 
@NgModule({
  declarations: [
    AppComponent,
    EmployeeInfoComponent,
    EmployeesComponent,

  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AppRoutingModule
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }

