import { TestBed, inject } from '@angular/core/testing';

import { EmployeeDatabaseService } from './employee-database.service';

describe('EmployeeDatabaseService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EmployeeDatabaseService]
    });
  });

  it('should be created', inject([EmployeeDatabaseService], (service: EmployeeDatabaseService) => {
    expect(service).toBeTruthy();
  }));
});
