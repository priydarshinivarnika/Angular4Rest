import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
 
import { EmployeeInfoComponent } from '../employee-info/employee-info.component';
import { EmployeesComponent } from '../employees/employees.component';
 
const routes: Routes = [
  { path: 'information/:id', component: EmployeeInfoComponent },
  { path: 'employees', component: EmployeesComponent }
];
 
@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { }
