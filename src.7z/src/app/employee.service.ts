import { Injectable } from '@angular/core';
import { Employee } from './employee'
import { EMPLOYEES } from './employee-store';
 
@Injectable()
export class EmployeeService {
  getEmployee(id: number): Promise<Employee> {
    return this.getEmployees()
               .then(employees => employees.find(employee => employee.id === id));
  }
  constructor() { }
  getEmployees(): Promise<Employee[]>{
    return Promise.resolve(EMPLOYEES);

}

}
