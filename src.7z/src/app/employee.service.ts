import { Injectable } from '@angular/core';
import { Employee } from './employee'
import 'rxjs/add/operator/toPromise';
import { Headers, Http } from '@angular/http';
import { EMPLOYEES } from './employee-store';


@Injectable()
export class EmployeeService {
/* 
 constructor() { }

  getEmployee(id: number): Promise<Employee> {
    return this.getEmployees()
               .then(employees => employees.find(employee => employee.id === id));
  }

  getEmployees(): Promise<Employee[]> {
    return Promise.resolve(EMPLOYEES);
  }
  */

  
   constructor(private http: Http)//Injects Http service
   {
 
  }
  private headers = new Headers({ 'Content-Type': 'application/json' });
  private employeesUrl = 'api/employees';

  getEmployees()// invokes the “api/employees” url and converts the response to a Promise
  : Promise<Employee[]>{
    return this.http.get(this.employeesUrl)
      .toPromise()
      .then(response => response.json().data as Employee[])
      .catch(this.handleError);

}

getEmployee(id: number)//does the same job as of getEmployees() but for a specifid employee
: Promise<Employee> {
  const url = `${this.employeesUrl}/${id}`;
  return this.http.get(url)
    .toPromise()
    .then(response => response.json().data as Employee)
    .catch(this.handleError);
}

createEmployee(employee: Employee): Promise<Employee> {
    return this.http
      .post(this.employeesUrl, JSON.stringify(employee), { headers: this.headers })
      .toPromise()
      .then(res => res.json().data as Employee)
      .catch(this.handleError);
  }
 
  updateEmployee(employee: Employee): Promise<Employee> {
    const url = `${this.employeesUrl}/${employee.id}`;
    return this.http
      .put(url, JSON.stringify(employee), { headers: this.headers })
      .toPromise()
      .then(() => employee)
      .catch(this.handleError);
  }
 
  deleteEmployee(employee: Employee): Promise<void> {
    const url = `${this.employeesUrl}/${employee.id}`;
    return this.http.delete(url, { headers: this.headers })
      .toPromise()
      .then(() => null)
      .catch(this.handleError);
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
 
}
