import { Employee } from './employee';

export const EMPLOYEES: Employee[] = [
  { id: 1, firstName: 'Dhyan', lastName: 'Ravindran', department: 'Development', skill: 'SDLC' },
  { id: 2, firstName: 'Murli', lastName: 'Naraynan', department: 'Development', skill: 'Java' },
  { id: 3, firstName: 'Ajaya', lastName: 'Kumari', department: 'Development', skill: 'Spring' },
  { id: 4, firstName: 'Sree', lastName: 'Rekha', department: 'Development', skill: 'Java' },
  { id: 5, firstName: 'Uma', lastName: 'Pulli', department: 'Development', skill: 'AutomationTesting' }
];