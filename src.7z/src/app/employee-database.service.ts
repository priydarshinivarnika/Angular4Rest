
import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';

@Injectable()
export class EmployeeDatabaseService  implements InMemoryDbService//creates a database from which values can be returned or updated
 {

  constructor() { }
  createDb() //return an object which holds the arrays
   {
let employees = [
{ id: 1, firstName: 'Dhyan', lastName: 'Ravindran', department: 'Development', skill: 'SDLC' },
{ id: 2, firstName: 'Murli', lastName: 'Naraynan', department: 'Development', skill: 'Java' },
{ id: 3, firstName: 'Ajaya', lastName: 'Kumari', department: 'Development', skill: 'Spring' },
{ id: 4, firstName: 'Sree', lastName: 'Rekha', department: 'Development', skill: 'Java' },
{ id: 5, firstName: 'Uma', lastName: 'Pulli', department: 'Development', skill: 'AutomationTesting' }
];
return {employees};

  }
}
