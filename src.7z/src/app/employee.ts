export class Employee {

        id: number;
        firstName: String;
        lastName: String;
        department: String;
        skill: String;

}
